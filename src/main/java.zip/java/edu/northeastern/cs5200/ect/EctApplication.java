package edu.northeastern.cs5200.ect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EctApplication {

	public static void main(String[] args) {
		SpringApplication.run(EctApplication.class, args);
	}

}
