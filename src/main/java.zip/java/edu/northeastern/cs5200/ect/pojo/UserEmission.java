package edu.northeastern.cs5200.ect.pojo;

import lombok.Data;

@Data
public class UserEmission {
    private Integer userId;
    private String eType;
} 