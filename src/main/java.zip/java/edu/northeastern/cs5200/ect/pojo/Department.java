package edu.northeastern.cs5200.ect.pojo;

import lombok.Data;

@Data
public class Department {
    private Integer departmentId;
    private String departmentName;
} 