package edu.northeastern.cs5200.ect.pojo;

import lombok.Data;

@Data
public class EmployeeInfo {
    private Integer employeeId;
    private String jobTitle;
    private String name;
    private Double salary;
} 